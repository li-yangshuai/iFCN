# iFCN QCA paper package

This archive contains the compile-ready manuscript and the compact
reproducibility artifacts used by its experiments.

## Build

Run the following command in this directory:

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error paper.tex
```

The required TeX class and bibliography style (`acmart` and
`ACM-Reference-Format`) are expected to be installed in the TeX distribution.

## Contents

- `paper.tex`: main manuscript; the simulation overview is inline TikZ.
- `random_clock_experiment.tex`: random-clock TOY/MAJ experiment section.
- `references.bib`: bibliography database.
- `paper.pdf`: verified compiled manuscript.
- `data/random_clock/`: layout, routing, timing, area, simulation, and
  validation results for the random-clock TOY/MAJ study.
- `data/physical_review_response/`: compact primary, ablation, dielectric,
  compiler, production, and legacy-crosscheck summaries.
- `scripts/benchmark_random_clock_toy_maj.py`: experiment aggregation script.
- `figures/`: retained manuscript-related artwork.

Generated LaTeX auxiliary files are deliberately excluded.
